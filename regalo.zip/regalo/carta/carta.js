// =====================================================
//  FLORES (rosa, gardenia, tulipán) dibujadas con SVG
// =====================================================
function rosa() {
  return (
    '<svg viewBox="0 0 100 100"><g stroke="#7a0c3a" stroke-opacity=".35" stroke-width=".8">' +
    '<g fill="url(#gRosaA)">' +
    [0, 72, 144, 216, 288].map((a) => '<ellipse cx="50" cy="26" rx="20" ry="24" transform="rotate(' + a + ' 50 50)"/>').join("") +
    '</g><g fill="url(#gRosaB)">' +
    [36, 108, 180, 252, 324].map((a) => '<ellipse cx="50" cy="32" rx="16" ry="19" transform="rotate(' + a + ' 50 50)"/>').join("") +
    '</g><g fill="url(#gRosaC)">' +
    [0, 90, 180, 270].map((a) => '<ellipse cx="50" cy="39" rx="11" ry="13" transform="rotate(' + a + ' 50 50)"/>').join("") +
    '</g></g>' +
    '<path d="M50 50 c0-4 5-4 5 0 s-2 7-8 6 s-9-8-5-13 s12-6 16 0" fill="none" stroke="#7a0c3a" stroke-opacity=".5" stroke-width="1.2" stroke-linecap="round"/></svg>'
  );
}

function gardenia() {
  return (
    '<svg viewBox="0 0 100 100">' +
    '<path d="M50 52 C22 50 6 72 18 92 C38 96 50 78 50 52Z" fill="#4f8a5b"/>' +
    '<path d="M50 52 C78 50 94 72 82 92 C62 96 50 78 50 52Z" fill="#3f7a4d"/>' +
    '<g stroke="#cdbfd6" stroke-width=".8" stroke-opacity=".8"><g fill="url(#gGard)">' +
    [0, 60, 120, 180, 240, 300].map((a) => '<path d="M50 50 C28 42 24 14 50 8 C76 14 72 42 50 50Z" transform="rotate(' + a + ' 50 50)"/>').join("") +
    '</g><g fill="url(#gGard)">' +
    [30, 90, 150, 210, 270, 330].map((a) => '<path d="M50 50 C34 44 32 24 50 19 C68 24 66 44 50 50Z" transform="rotate(' + a + ' 50 50)"/>').join("") +
    '</g></g><circle cx="50" cy="50" r="6" fill="#f2e7cf"/>' +
    '<path d="M50 50 c0-3 4-3 4 0 s-2 5-6 4" fill="none" stroke="#c9b48a" stroke-width="1.2" stroke-linecap="round"/></svg>'
  );
}

function tulipan(g1, g2) {
  return (
    '<svg viewBox="0 0 100 140">' +
    '<path d="M50 140 C49 115 50 95 50 72" fill="none" stroke="#3f7a4d" stroke-width="5" stroke-linecap="round"/>' +
    '<path d="M50 138 C28 124 16 96 20 68 C38 82 49 108 50 138Z" fill="#4f8a5b"/>' +
    '<path d="M50 138 C72 124 84 96 80 68 C62 82 51 108 50 138Z" fill="#3f7a4d"/>' +
    '<path d="M28 26 C24 54 36 76 50 76 C64 76 76 54 72 26 C64 36 57 26 50 12 C43 26 36 36 28 26Z" fill="url(#' + g1 + ')" stroke="rgba(120,20,60,.3)" stroke-width=".8"/>' +
    '<path d="M38 24 C34 52 42 76 50 76 C58 76 66 52 62 24 C58 32 54 22 50 10 C46 22 42 32 38 24Z" fill="url(#' + g2 + ')" stroke="rgba(120,20,60,.25)" stroke-width=".8"/>' +
    '</svg>'
  );
}

function hoja() {
  return (
    '<svg viewBox="0 0 60 100">' +
    '<path d="M30 98 C5 70 5 25 30 2 C55 25 55 70 30 98Z" fill="#4f8a5b"/>' +
    '<path d="M30 94 L30 12" stroke="#3a6c46" stroke-width="1.5" fill="none" stroke-linecap="round"/></svg>'
  );
}

const DIBUJO = {
  rosa: { svg: rosa, alto: 1 },
  gardenia: { svg: gardenia, alto: 1 },
  tulipan: { svg: () => tulipan("gTulA", "gTulB"), alto: 1.4, origen: "50% 100%" },
  tulipan2: { svg: () => tulipan("gTulC", "gTulD"), alto: 1.4, origen: "50% 100%" },
  hoja: { svg: hoja, alto: 1.6, origen: "50% 100%" }
};

// [tipo, izquierda, arriba, derecha, abajo, ancho, giro]  (en em; null = no se usa)
const FLORES = [
  // esquina de arriba a la izquierda
  ["hoja", -2, -4, null, null, 4, -50],
  ["hoja", 4, -5, null, null, 4, 20],
  ["tulipan", -2.5, -7.5, null, null, 6.5, -28],
  ["rosa", -3.8, -3, null, null, 9, 15],
  ["gardenia", 3.2, -4.5, null, null, 8.5, -8],
  ["rosa", 7.4, -1.4, null, null, 4.8, 40],
  // esquina de arriba a la derecha
  ["hoja", null, -4.5, -2, null, 4, 50],
  ["hoja", null, -5, 5, null, 4, -20],
  ["tulipan2", null, -7.5, -2.5, null, 6.5, 28],
  ["gardenia", null, -3.4, -3.8, null, 9.5, 10],
  ["rosa", null, -4, 4.4, null, 7.5, -12],
  ["gardenia", null, -1, 9, null, 4.8, 30],
  // esquina de abajo a la izquierda
  ["hoja", -2.5, null, null, -4, 4, -70],
  ["tulipan", 3, null, null, -6, 6, -12],
  ["rosa", -3.2, null, null, -3.6, 8, -10],
  ["gardenia", 6.8, null, null, -2.4, 6, 12],
  // esquina de abajo a la derecha
  ["hoja", null, null, -2.5, -4, 4, 70],
  ["tulipan2", null, null, -1.8, -6.5, 6, 16],
  ["gardenia", null, null, -3.4, -3.4, 9, -6],
  ["rosa", null, null, 4.4, -3.8, 7, 22]
];

const deco = document.getElementById("deco");
FLORES.forEach((f, i) => {
  const tipo = DIBUJO[f[0]];
  const el = document.createElement("div");
  el.className = "fd";
  el.innerHTML = tipo.svg();
  if (f[1] !== null) el.style.left = f[1] + "em";
  if (f[2] !== null) el.style.top = f[2] + "em";
  if (f[3] !== null) el.style.right = f[3] + "em";
  if (f[4] !== null) el.style.bottom = f[4] + "em";
  el.style.setProperty("--w", f[5] + "em");
  el.style.setProperty("--h", f[5] * tipo.alto + "em");
  el.style.setProperty("--r", f[6] + "deg");
  el.style.setProperty("--dl", -((i * 0.7) % 5) + "s");
  if (tipo.origen) el.style.setProperty("--o", tipo.origen);
  deco.appendChild(el);
});

// =====================================================
//  PÉTALOS que caen lento en el fondo
// =====================================================
const contPetalos = document.getElementById("petalos");
const PARES = [
  ["#ffd1e0", "#ff8fb5"],
  ["#ffffff", "#ffd9e6"],
  ["#ffc2d8", "#e8457f"],
  ["#ffe3c4", "#ffa57a"]
];

function soltarPetalo(retraso) {
  if (contPetalos.children.length >= 18) return;
  const p = document.createElement("span");
  const par = PARES[Math.floor(Math.random() * PARES.length)];
  p.className = "petalo";
  p.style.setProperty("--x", Math.random() * 98 + "vw");
  p.style.setProperty("--s", 12 + Math.random() * 12 + "px");
  p.style.setProperty("--d", 16 + Math.random() * 12 + "s");
  p.style.setProperty("--sway", 30 + Math.random() * 70 + "px");
  p.style.setProperty("--c1", par[0]);
  p.style.setProperty("--c2", par[1]);
  if (retraso) p.style.setProperty("--delay", retraso + "s");
  p.addEventListener("animationend", () => p.remove());
  contPetalos.appendChild(p);
}

[-2, -5, -8, -11, -14].forEach((r) => soltarPetalo(r));
setInterval(() => soltarPetalo(0), 1800);
