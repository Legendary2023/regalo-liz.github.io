// =====================================================
//  PERSONALIZA AQUÍ
// =====================================================

var audio = document.querySelector("audio");
var lyrics = document.querySelector("#lyrics");

const CONFIG = {
  tituloPortada: "Para ti",
  subtituloPortada: "un álbum de nuestros recuerdos",
  tituloPagina: "Nuestros recuerdos",
  totalFotos: 120,          // cuántas fotos tienes
  carpeta: "fotos/",        // carpeta donde están las fotos
  prefijo: "foto",          // foto1.jpg, foto2.jpg, foto3.jpg ...
  volumen: 0.7              // de 0 a 1
};

// Extensiones que intentará probar para cada foto (en este orden)
const EXTENSIONES = ["jpg", "jpeg", "png", "webp", "JPG", "JPEG", "PNG"];

// OPCIONAL: si tus fotos NO se llaman foto1, foto2... escribe aquí los nombres
// exactos en orden. Ejemplo: ["playa.jpg", "cumple.png", "viaje.jpeg"]
// Si lo dejas vacío, se usa el nombre foto1, foto2...
const ARCHIVOS = [];

// Mensajes propios por número de foto (los que no pongas usan los de abajo)
const MENSAJES = {
  1: "Aquí empezó todo… y qué bonito ha sido el camino contigo.",
  2: "Contigo hasta un día cualquiera se vuelve especial.",
  3: "Esta sonrisa dice más que mil palabras, y todas son buenas.",
  4: "Gracias por estar siempre. De verdad, siempre."
};

const MENSAJES_GENERICOS = [
 
  "Oye, por si hoy nadie te lo ha dicho, estoy muy orgulloso de ti.",
  "A veces se te olvida lo mucho que vales, pero espero que nunca dejes de recordarlo.",
  "No te preocupes si hoy las cosas no salieron bien, mañana lo intentamos otra vez.",
  "De verdad espero que un día consigas todo eso que me has contado que quieres lograr.",
  "No sabes lo bonito que es verte feliz, ojalá tuvieras más días así.",
  "No te rindas todavía, quién sabe si estás más cerca de lo que piensas.",
  "Está bien cansarse, solo no olvides que puedes descansar y volver a intentarlo.",
  "Si vieras todo lo bueno que veo en ti, dejarías de dudar tanto de ti misma.",
  "Espero que algún día te des cuenta de que eres capaz de mucho más de lo que crees.",
  "No tienes que tener un buen día para seguir siendo alguien increíble.",
  "No te exijas tanto, estás aprendiendo a vivir y nadie tiene un manual para hacerlo.",
  "Acuérdate de que no todo lo tienes que resolver hoy, ve poquito a poquito.",
  "Ojalá nunca te falten ganas de hacer eso que tanto te emociona.",
  "A veces solo necesitas darte una oportunidad más, no rendirte contigo misma.",
  "Me da gusto verte avanzar, aunque tú sientas que vas muy despacio.",
  "No sabes lo bonito que es compartir momentos con alguien con quien puedes reírte de cualquier cosa.",
  "Tú sigue intentando, que equivocarse también es parte de aprender.",
  "Hay días en los que no sale nada bien y aun así mereces estar orgullosa de ti.",
  "Espero que la vida te sorprenda con cosas tan bonitas como las que tú mereces.",
  "No sé cómo te vaya mañana, pero espero que sea un poquito mejor que hoy.",
  "Si algo no te sale a la primera, tampoco pasa nada, nadie nace sabiendo.",
  "Me gusta ver cómo poco a poco vas logrando cosas que antes parecían lejanas.",
  "No te compares con nadie, bastante tienes con construir tu propia historia.",
  "Ojalá nunca dejes que un mal momento te haga pensar mal de ti.",
  "Tú puedes con mucho, pero tampoco tienes que poder con todo al mismo tiempo.",
  "De verdad quiero verte cumplir tus sueños, aunque te tardes y tengas que empezar varias veces.",
  "No olvides que también has tenido días difíciles y aquí sigues, haciendo lo mejor que puedes.",
  "A veces no necesitas hacer más, solo reconocer que ya hiciste bastante por hoy.",
  "Me alegra mucho cuando me cuentas algo que te salió bien, se nota cuando algo te hace feliz.",
  "Nunca pienses que tus pequeños logros no cuentan, yo sé lo que cuesta conseguir algunas cosas.",
  "Si alguna vez sientes que no avanzas, recuerda que crecer no siempre se nota de inmediato.",
  "No te voy a decir que todo será fácil, pero sí que vale la pena seguir intentando.",
  "Tienes un montón de cosas por vivir, no dejes que un mal día te haga olvidarlo.",
  "Si hoy te sientes perdida, no pasa nada, a veces también necesitamos tiempo para encontrarnos.",
  "Quiero que algún día mires atrás y te sientas feliz de no haber dejado de intentarlo.",
  "No necesitas tener la vida resuelta para disfrutar lo que tienes ahora.",
  "A veces me gustaría que pudieras ver lo bonito que es ser tú sin estar pensando tanto en tus defectos.",
  "Sigue haciendo las cosas a tu manera, no todo tiene que salir como los demás esperan.",
  "Espero que te pasen cosas bonitas, de esas que llegan cuando menos las esperas.",
  "No te olvides de ti por estar pendiente de que todos los demás estén bien.",
  "Me encanta cuando me cuentas tus planes, ojalá algún día podamos decir que todos esos sueños se cumplieron.",
  "No importa si hoy solo pudiste hacer un poquito, mañana puedes continuar.",
  "Nunca es tarde para aprender algo nuevo o intentar algo que siempre te dio curiosidad.",
  "Si algo te hace feliz y no le hace daño a nadie, date la oportunidad de disfrutarlo.",
  "No tienes que demostrar que eres fuerte todo el tiempo, también puedes pedir ayuda.",
  "Espero que nunca pierdas esa forma tan tuya de reírte por cualquier tontería.",
  "Qué bonito sería que pudieras guardar los días felices para recordarlos cuando los necesites.",
  "No sabes lo mucho que puede cambiar un día con una buena plática y alguien que te escuche.",
  "A veces lo mejor que puedes hacer es dejar de pensar tanto y darte un respiro.",
  "Me da mucho gusto que estés aquí, haciendo tu camino aunque a veces no sea sencillo.",
  "No dejes que las cosas que todavía no consigues te hagan olvidar todo lo que ya tienes.",
  "Quiero que tengas motivos para sentirte orgullosa de ti, no solo de las cosas que haces por los demás.",
  "Si hoy las cosas se sienten pesadas, tómatelo con calma, no tienes que resolverlo todo de golpe.",
  "Ojalá encuentres algo bonito incluso en esos días que empiezan bastante mal.",
  "Me gusta que podamos compartir momentos que no necesitan ser perfectos para ser buenos.",
  "Algún día vas a recordar muchas de tus preocupaciones de hoy y te vas a dar cuenta de que pudiste salir adelante.",
  "No te desanimes porque alguien más vaya más rápido, tú también estás avanzando.",
  "De verdad espero que nunca te falte alguien que crea en ti cuando tú tengas dudas.",
  "No olvides que descansar un rato no significa que estés dejando de esforzarte.",
  "Ojalá te atrevas a hacer eso que llevas tiempo queriendo hacer, aunque te dé un poquito de miedo.",
  "Me pone feliz saber que sigues intentando las cosas que son importantes para ti.",
  "No todo lo que vale la pena llega rápido, a veces toca tener paciencia.",
  "Si hoy te salió algo mal, no significa que mañana tenga que pasar lo mismo.",
  "No tienes idea de lo bonito que es ver a alguien esforzarse por algo que realmente quiere.",
  "Espero que nunca te acostumbres a pensar que tienes que conformarte con menos de lo que te hace feliz.",
  "A veces necesitas recordar que eres una persona, no una máquina que tiene que hacerlo todo bien.",
  "Ojalá te des permiso de disfrutar las cosas sin sentir que siempre deberías estar haciendo algo productivo.",
  "No importa si tienes que cambiar tus planes, lo importante es encontrar algo que te haga sentir bien contigo.",
  "Qué gusto me da cuando te pasan cosas buenas, hasta parece que el día se pone mejor.",
  "Nunca sabes qué puede pasar si decides intentarlo una vez más.",
  "No tienes que saber exactamente qué hacer con tu vida a estas alturas, tranquila.",
  "Me gustaría que tuvieras más días en los que te sientas en paz contigo misma.",
  "Sigue buscando eso que te hace levantarte con ganas, aunque tardes un poco en encontrarlo.",
  "A veces las cosas mejoran de formas que ni siquiera habíamos imaginado.",
  "No olvides que mereces celebrar cuando algo te sale bien, por pequeño que parezca.",
  "Ojalá algún día puedas ver tus avances sin pensar inmediatamente en todo lo que te falta.",
  "Me gusta saber de tus sueños, así que no dejes de contarme esas cosas que te ilusionan.",
  "Si algo no salió como querías, date chance de sentirte mal un rato y después vuelve a intentarlo.",
  "La verdad, espero que te vaya muy bonito en todo lo que te propongas.",
  "No necesitas cambiar para gustarle a todo el mundo, quédate con quien te aprecie como eres.",
  "Acuérdate de que también mereces recibir todo ese cariño que les das a los demás.",
  "Espero que nunca te falte alguien con quien puedas hablar sin tener que fingir que todo está bien.",
  "Qué bonito es tener recuerdos que todavía te sacan una sonrisa aunque ya haya pasado tiempo.",
  "A veces no nos damos cuenta de que estamos viviendo momentos que después vamos a extrañar.",
  "Gracias por las veces que me has hecho reír sin siquiera intentarlo.",
  "Hay personas con las que no importa qué hagas, siempre terminas pasando un buen rato.",
  "Me alegra haber coincidido contigo, porque conocerte ha sido algo muy bonito.",
  "Ojalá nos queden muchas tardes de pláticas, risas y momentos que después recordemos con cariño.",
  "No hace falta que pase algo increíble para que un día contigo se vuelva especial.",
  "A veces una foto termina guardando mucho más que el momento en que la tomamos.",
  "Qué bueno que existen personas que hacen que los días normales se sientan diferentes.",
  "Espero que cuando veas esta foto recuerdes que también has tenido momentos muy bonitos.",
  "Hay recuerdos que uno no planea, pero que termina guardando con muchísimo cariño.",
  "Gracias por formar parte de momentos que no cambiaría por nada.",
  "Me gusta pensar que todavía nos faltan muchas historias por contar.",
  "No sé si te lo digo lo suficiente, pero me alegra mucho tenerte en mi vida.",
  "Ojalá nunca nos falten motivos para reírnos de las mismas tonterías de siempre.",
  "Qué bonito coincidir con alguien con quien puedes pasar horas hablando de cualquier cosa.",
  "Espero que nunca olvides las cosas buenas que has hecho sentir a las personas que te quieren.",
  "A veces las personas más especiales no se dan cuenta de lo importantes que son.",
  "Si alguna vez dudas de ti, acuérdate de que hay personas que te aprecian tal como eres.",
  "No necesitas hacer algo extraordinario para que alguien disfrute tenerte cerca.",
  "Me gusta que seas parte de mi historia, incluso en esos capítulos que parecían cualquier cosa.",
  "Ojalá la vida nos permita seguir juntando recuerdos de esos que dan ganas de volver a vivir.",
  "Gracias por ser parte de mis días y por todas esas veces que terminamos riéndonos por nada.",
  "Si pudiera guardar algunos momentos para volver a vivirlos, seguramente elegiría varios de estos.",
  "Qué suerte haber vivido este momento contigo, aunque en ese instante pareciera uno más.",
  "Espero que siempre encuentres motivos para seguir adelante y personas con quienes compartir lo bueno.",
  "Y por si se te olvida algún día, quiero que sepas que vales mucho, que puedes aprender de todo esto y que todavía te quedan muchísimas cosas bonitas por vivir."

];
// =====================================================

const TOTAL = ARCHIVOS.length || CONFIG.totalFotos;
const TOTAL_APERTURAS = Math.max(1, Math.ceil(TOTAL / 4)); // 4 fotos por apertura (2 por hoja)

const libro = document.getElementById("libro");
const escala = document.getElementById("escala");
const pagIzq = document.getElementById("pagIzq");
const pagDer = document.getElementById("pagDer");
const flipper = document.getElementById("flipper");
const fFrente = document.getElementById("fFrente");
const fAtras = document.getElementById("fAtras");
const pista = document.getElementById("pista");
// La música la maneja ../musica.js (compartida entre páginas)
const visor = document.getElementById("visor");
const visorImg = document.getElementById("visorImg");
const visorMsg = document.getElementById("visorMsg");
const visorCerrar = document.getElementById("visorCerrar");

let estado = "cerrado";
let actual = 0;          // apertura (par de hojas) que se está viendo
let animando = false;

// Imagen de reemplazo mientras no pongas la foto real
const PLACEHOLDER = "data:image/svg+xml;utf8," + encodeURIComponent(
  "<svg xmlns='http://www.w3.org/2000/svg' width='800' height='600'>" +
  "<defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'>" +
  "<stop offset='0' stop-color='#f6d9e2'/><stop offset='1' stop-color='#e9d5f2'/></linearGradient></defs>" +
  "<rect width='800' height='600' fill='url(#g)'/>" +
  "<text x='400' y='300' font-size='72' text-anchor='middle' fill='#b24a6c' font-family='Georgia,serif'>♥</text>" +
  "<text x='400' y='370' font-size='32' text-anchor='middle' fill='#8a4a62' font-family='Georgia,serif'>Aquí va tu foto</text>" +
  "</svg>"
);

// ---------- Fotos ----------
function srcFoto(n, intento) {
  if (ARCHIVOS.length) return intento === 0 ? CONFIG.carpeta + ARCHIVOS[n - 1] : null;
  const ext = EXTENSIONES[intento];
  return ext ? CONFIG.carpeta + CONFIG.prefijo + n + "." + ext : null;
}

// Si una foto no carga, prueba otra extensión; al final pone el recuadro de reemplazo
function fotoFallo(img) {
  const n = Number(img.dataset.n);
  const intento = (Number(img.dataset.intento) || 0) + 1;
  img.dataset.intento = intento;
  const siguiente = srcFoto(n, intento);
  if (siguiente) {
    img.src = siguiente;
  } else {
    img.onerror = null;
    img.src = PLACEHOLDER;
  }
}

function mensajeDe(n) {
  return MENSAJES[n] || MENSAJES_GENERICOS[(n - 1) % MENSAJES_GENERICOS.length];
}

// Ajusta cada foto al espacio de su hoja, respetando su proporción
function ajustar(img) {
  const slot = img.closest(".slot");
  if (!slot || !slot.clientWidth || !img.naturalWidth) return;
  const maxW = slot.clientWidth - 44;
  const maxH = slot.clientHeight - 52;
  let r = Math.min(maxW / img.naturalWidth, maxH / img.naturalHeight);
  r = Math.min(r, 2); // no agrandar demasiado las fotos pequeñas
  img.style.width = Math.round(img.naturalWidth * r) + "px";
  img.style.height = Math.round(img.naturalHeight * r) + "px";
}
document.addEventListener("load", (e) => {
  if (e.target.tagName === "IMG") ajustar(e.target);
}, true);

// ---------- Hojas ----------
function paginaHTML(lado, s) {
  const izq = lado === "izq";
  const primera = s * 4 + (izq ? 0 : 2);
  const numPag = s * 2 + (izq ? 1 : 2);

  let slots = "";
  for (let k = 1; k <= 2; k++) {
    const n = primera + k;
    if (n <= TOTAL) {
      slots +=
        '<div class="slot"><button class="frame" type="button" data-n="' + n + '" aria-label="Abrir la foto ' + n + '">' +
        '<img data-n="' + n + '" src="' + srcFoto(n, 0) + '" alt="Foto ' + n + '" decoding="async" onerror="fotoFallo(this)">' +
        "</button></div>";
    } else {
      slots += '<div class="slot vacio"><span>♥</span></div>';
    }
  }

  const btnPrev =
    '<button class="nav nav-prev" type="button" data-dir="-1"' + (s === 0 ? " disabled" : "") + ">" +
    '<span class="flecha">←</span> Anterior</button>';
  const btnNext =
    '<button class="nav nav-next" type="button" data-dir="1"' + (s >= TOTAL_APERTURAS - 1 ? " disabled" : "") + ">" +
    'Siguiente <span class="flecha">→</span></button>';
  const num = '<span class="num">' + numPag + "</span>";

  return (
    '<div class="page-inner">' +
    '<header class="cabecera">✿ ' + CONFIG.tituloPagina + " ✿</header>" +
    '<div class="slots">' + slots + "</div>" +
    '<footer class="pie">' + (izq ? btnPrev + num : num + btnNext) + "</footer>" +
    "</div>"
  );
}

function mostrar(s) {
  pagIzq.innerHTML = paginaHTML("izq", s);
  pagDer.innerHTML = paginaHTML("der", s);
  actual = s;
  precargarVecinos();
}

function precargarVecinos() {
  [actual - 1, actual + 1].forEach((s) => {
    if (s < 0 || s >= TOTAL_APERTURAS) return;
    for (let k = 1; k <= 4; k++) {
      const n = s * 4 + k;
      if (n <= TOTAL) new Image().src = srcFoto(n, 0);
    }
  });
}

// Pasar de página con una hoja que gira
function pasar(dir) {
  const nuevo = actual + dir;
  if (animando || nuevo < 0 || nuevo >= TOTAL_APERTURAS) return;
  animando = true;

  const htmlIzq = paginaHTML("izq", nuevo);
  const htmlDer = paginaHTML("der", nuevo);

  flipper.style.transition = "none";
  flipper.style.transform = "rotateY(0deg)";

  if (dir > 0) {
    flipper.className = "flipper next show";
    fFrente.className = "page right";
    fFrente.innerHTML = pagDer.innerHTML;
    fAtras.className = "page left atras";
    fAtras.innerHTML = htmlIzq;
    pagDer.innerHTML = htmlDer;
  } else {
    flipper.className = "flipper prev show";
    fFrente.className = "page left";
    fFrente.innerHTML = pagIzq.innerHTML;
    fAtras.className = "page right atras";
    fAtras.innerHTML = htmlDer;
    pagIzq.innerHTML = htmlIzq;
  }

  void flipper.offsetWidth; // fuerza a aplicar el estado inicial
  flipper.style.transition = "transform 1s cubic-bezier(.45, .05, .25, 1)";
  flipper.style.transform = dir > 0 ? "rotateY(-180deg)" : "rotateY(180deg)";

  setTimeout(() => {
    if (dir > 0) pagIzq.innerHTML = htmlIzq;
    else pagDer.innerHTML = htmlDer;
    flipper.classList.remove("show");
    actual = nuevo;
    animando = false;
    precargarVecinos();
  }, 1050);
}

// ---------- Efectos de los botones ----------
function efectoBoton(btn, e) {
  const r = btn.getBoundingClientRect();
  const k = r.width / btn.offsetWidth || 1;
  const teclado = !e.clientX && !e.clientY;
  const x = teclado ? r.width / 2 : e.clientX - r.left;
  const y = teclado ? r.height / 2 : e.clientY - r.top;

  const d = Math.max(btn.offsetWidth, btn.offsetHeight) * 2;
  const rip = document.createElement("span");
  rip.className = "ripple";
  rip.style.width = rip.style.height = d + "px";
  rip.style.left = x / k - d / 2 + "px";
  rip.style.top = y / k - d / 2 + "px";
  btn.appendChild(rip);
  setTimeout(() => rip.remove(), 700);

  const simbolos = ["♥", "✦", "❀"];
  for (let i = 0; i < 7; i++) {
    const s = document.createElement("span");
    s.className = "mini-corazon";
    s.textContent = simbolos[i % simbolos.length];
    const ang = -Math.PI / 2 + (Math.random() - 0.5) * Math.PI;
    const dist = 40 + Math.random() * 55;
    s.style.left = r.left + r.width / 2 + "px";
    s.style.top = r.top + r.height / 2 + "px";
    s.style.setProperty("--dx", Math.cos(ang) * dist + "px");
    s.style.setProperty("--dy", Math.sin(ang) * dist + "px");
    document.body.appendChild(s);
    setTimeout(() => s.remove(), 950);
  }
}

// ---------- Foto ampliada ----------
function abrirVisor(n) {
  visorImg.dataset.n = n;
  visorImg.dataset.intento = 0;
  visorImg.onerror = () => fotoFallo(visorImg);
  visorImg.src = srcFoto(n, 0);
  visorImg.alt = "Foto " + n;
  visorMsg.textContent = mensajeDe(n);
  visor.hidden = false;
  visorCerrar.focus();
}

function cerrarVisor() {
  visor.hidden = true;
  visorImg.removeAttribute("src");
}

visor.addEventListener("click", (e) => {
  if (e.target === visor) cerrarVisor();
});
visorCerrar.addEventListener("click", cerrarVisor);
document.addEventListener("keydown", (e) => {
  if (e.key === "Escape" && !visor.hidden) cerrarVisor();
});

// ---------- Abrir el libro ----------
function escalar() {
  const w = window.innerWidth;
  const h = window.innerHeight;
  const s = estado === "cerrado"
    ? Math.min((w * 0.82) / 500, (h * 0.78) / 640, 1.4)
    : Math.min((w * 0.95) / 1000, (h * 0.88) / 640, 1.3);
  escala.style.setProperty("--s", s);
}

function abrir() {
  if (estado !== "cerrado") return;
  estado = "abierto";
  libro.classList.remove("closed");
  libro.classList.add("open");
  libro.removeAttribute("role");
  libro.removeAttribute("tabindex");
  libro.removeAttribute("aria-label");
  escala.classList.add("abierto");
  pista.classList.add("oculta");
  escalar();
}

libro.addEventListener("click", (e) => {
  if (estado === "cerrado") {
    abrir();
    return;
  }
  const nav = e.target.closest(".nav");
  if (nav) {
    if (!nav.disabled && !animando) {
      efectoBoton(nav, e);
      pasar(Number(nav.dataset.dir));
    }
    return;
  }
  const marco = e.target.closest(".frame");
  if (marco) abrirVisor(Number(marco.dataset.n));
});

libro.addEventListener("keydown", (e) => {
  if (estado === "cerrado" && (e.key === "Enter" || e.key === " ")) {
    e.preventDefault();
    abrir();
  }
});


// ---------- Partículas de fondo ----------
function crearParticulas() {
  const cont = document.getElementById("particulas");
  const simbolos = ["♥", "✿", "❀", "✦", "❁", "♡"];
  const colores = [
    "rgba(255,255,255,.75)", "rgba(255,196,214,.8)",
    "rgba(255,228,170,.8)", "rgba(230,200,255,.75)"
  ];
  for (let i = 0; i < 30; i++) {
    const p = document.createElement("span");
    p.className = "petalo";
    p.textContent = simbolos[i % simbolos.length];
    p.style.setProperty("--x", Math.random() * 100 + "vw");
    p.style.setProperty("--s", 10 + Math.random() * 20 + "px");
    p.style.setProperty("--d", 14 + Math.random() * 16 + "s");
    p.style.setProperty("--delay", -Math.random() * 30 + "s");
    p.style.setProperty("--sway", Math.random() * 120 - 60 + "px");
    p.style.setProperty("--c", colores[i % colores.length]);
    cont.appendChild(p);
  }
}

// ---------- Inicio ----------
document.getElementById("tituloPortada").textContent = CONFIG.tituloPortada;
document.getElementById("subtituloPortada").textContent = CONFIG.subtituloPortada;
crearParticulas();
mostrar(0);
escalar();
window.addEventListener("resize", escalar);
